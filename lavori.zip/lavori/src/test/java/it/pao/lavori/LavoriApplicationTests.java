package it.pao.lavori;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LavoriApplicationTests {

	@Test
	void contextLoads() {
	}

}
